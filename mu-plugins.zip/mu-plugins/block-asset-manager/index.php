<?php


/**
 * 	Plugin Name:	FX Load More
 * 	Plugin URI: 	https://www.webfx.com
 * 	Description:	Adds "load more" functionality to blog and search results
 * 	Version: 		1.0.0
 * 	Author: 		The WebFX Team
 * 	Author URI: 	https://www.webfx.com
 * 	Text Domain: 	webfx
 */


class Block_Asset_Manager
{
	protected static $instance      = null;
	
	public static $plugin_path      = null;
    public static $plugin_path_inc  = null;
    public static $plugin_url       = null;


    public static $theme_base_path  = null;
    public static $theme_base_url   = null; 



    /**
     * Singleton instance
     *
     * @return  self
     */
	public static function instance() {
		if( null === self::$instance ) {
			self::$instance = new self();
        }

        return self::$instance;
	}


    /**
     * Constructor
     * 
     * @return  void
     */
    public function __construct()
    {
        $this->define();
        $this->include();
    }


    /**
     * Define common vars
     *
     * @return  void
     */
    public function define(): void
    {
        self::$plugin_path 		= plugin_dir_path( __FILE__ );
        self::$plugin_url 		= plugin_dir_url( __FILE__ );
        self::$plugin_path_inc 	= sprintf( '%sincludes/', self::$plugin_path );

        self::$theme_base_path    = get_stylesheet_directory();
        self::$theme_base_url     = get_stylesheet_directory_uri();        
    }


    /**
     * Include required files
     * 
     * @todo    separate includes conditionally by frontend/admin
     *
     * @return  void
     */
    private function include(): void
    {
        // load functions to internally support plugin
        require_once( self::$plugin_path_inc . '/helper-functions.php' );

        // load functions to help theme and other plugins interact with FX BAM
		require_once( self::$plugin_path_inc . '/public-functions.php' );
        
		require_once( self::$plugin_path_inc . '/classes/class-register-blocks.php' );
        require_once( self::$plugin_path_inc . '/classes/class-asset-minifier.php' );
		require_once( self::$plugin_path_inc . '/classes/class-assets.php' );
		require_once( self::$plugin_path_inc . '/classes/class-parse-block-assets.php' );
    }

}



/**
 * Returns main instance of Block_Asset_Manager to prevent need of global usage
 * @return Block_Asset_Manager
 */
function Block_Asset_Manager() {
	return Block_Asset_Manager::instance();
}

Block_Asset_Manager();
