<?php


/**
 * These functions are intended to be used solely within the FX Block Asset Manager plugin. 
 * 
 * If the function is intended to be used in other plugins or in the theme, please add the function to 
 * public-functions.php.
 */



/**
 * Convert argument to array with no falsey values
 *
 * @param	mixed   $arg        Argument of any type
 * @param   string  $separator  Separator for passing to explode()   
 * @return  array
 */
function bam_ensure_clean_array( $arg, string $separator = ' ' ): array {
	if( is_string( $arg ) ) {
		$arg = explode( $separator, $arg );
	} elseif( !is_array( $arg ) ) {
		$arg = (array)$arg;
	}

	// cleanup array
	$arg = array_values( $arg );
	$arg = array_filter( $arg ); // remove null values
	$arg = array_map( 'trim', $arg );
	$arg = array_unique( $arg );

	return $arg;
}


/**
 * Determine if site is in debug/development mode
 * 
 * @internal 		This is a one-to-one copy of debug_mode_enabled function in theme
 *
 * @param   bool    $include_dev_mode   Include check for development mode
 * @return  bool                        True, if in debug mode
 */
function bam_debug_mode_enabled( bool $include_dev_mode = true ): bool {

    // check for constants set in wp-config
    if( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
        return true;
    }

    // conditionally check if site is in development mode
    // if( $include_dev_mode && 'development' === wp_get_environment_type() ) {
    //     return true;
    // }

    return false;
}


/**
 * Get file url based on file path
 *
 * @param	string	$url    File URL
 * @return  mixed           String, if valid file; otherwise, false
 */
function bam_get_file_src_from_path( string $path ) {   
	// handle inconsistent filepaths
	$abspath = str_replace(
		['/', '\\'],
		DIRECTORY_SEPARATOR,
		ABSPATH,            
	);
	$path = str_replace(
		['/', '\\'],
		DIRECTORY_SEPARATOR,
		$path,            
	);

	// if ABSPATH from path
	if( false !== strpos( $path, $abspath ) ) {
		$path = substr_replace( $path, '', 0, strlen( $abspath ) );
	}
			
	$path = str_replace(
		DIRECTORY_SEPARATOR,
		'/',
		$path,            
	);
	
	return trailingslashit( site_url() ) . $path;
}