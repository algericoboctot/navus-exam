<?php


/**
 * Block Parser file
 * Contains logic for parsing block assets and enqueuing them
 * wherever the block is used to improve site speed.
 */
 
class ParseBlockAssets
{
    protected static $instance = null;
    protected static $fx_assets;
	
	protected function __construct( )
    {
        self::$fx_assets = Assets();
        // This runs with a priority of 102 so script/stylesheet tags modified by FX_Assets class will be applied.
		add_action('wp_enqueue_scripts', [$this, 'enqueue_block_assets'], 102);
	}
    
    /**
     * Static Singleton Factory Method
     * @return self returns a single instance of our class
     */
	public static function init() {
		if (!isset(self::$instance)) {
            $class_name = __CLASS__;
            self::$instance = new $class_name;
        }
        return self::$instance;
	}
    
    /** Returns blocks whose assets should be excluded from inlining
      * For example, block-scripts which have dependencies that make use of
      * wp_localize_script
      */
    public static function get_blocks_excluded_from_inline() {
        $excluded_blocks = [];
        return apply_filters('dont_inline_block_assets', $excluded_blocks);
    }
    
    /** This function loops through the blocks in the_content and 
     * enqueues assets for them. Assets for the first block will be inlined to
     * improve paint times, unless the block is excluded with the 
     * dont_inline_block_assets filter.
     */
    public function enqueue_block_assets() {

        $block_registrar = RegisterBlocks();
        
        $blocks = self::get_post_blocks();
        if (false === $blocks)
            return;

        // First, parse out non-fx blocks, and flatten blocks to make sure inner-blocks will be handled
        $blocks = $this->flatten_fx_blocks($blocks);
        $excluded_inline_blocks = $this->get_blocks_excluded_from_inline();
        
        $i = 0;
        $first_run = true;
        foreach ($blocks as $block) {              
       
            // Here, we'll get and remove the block from the registrar so we only have to process its assets once, in case one block is used more than once on a page.
            $block_name = $block['attrs']['name'] ?? null;
            $block_assets = $block_registrar->pop_block($block_name);
            $inline_assets = true;
            
            // Check for blocks that don't want their assets to be inlined
            if ( 0 == $i && in_array($block_name, $excluded_inline_blocks) ) {
                $inline_assets = false;
            }             
            
            // If the block is one of our registered blocks, enqueue assets for it here.
                        
            if ( $block_assets ) {
                
                $css = $block_assets['css'];
                $css_src = $css ? $css['src'] : false;
                $css_filepath = $css ? $css['path'] : false;
                $css_deps = $block_assets['css_deps'];
                
                $js = $block_assets['js'];
                $js_src = $js ? $js['src'] : false;
                $js_filepath = $js ? $js['path'] : false;
                $js_deps = $block_assets['js_deps'];
                
                // For first block, output inline styles
                if ($inline_assets && 0 == $i) {

                    if ($css) {
                        assets_add_stylesheet( [
                            'handle'      => $block_name,
                            'src'         => $css_src,
                            'inline'      => true,
                            'dependencies' => $css_deps,
                            'path'        => $css_filepath,
                        ]);
                        
                    }  // if no css, you can still specify dependencies
                    elseif ($css_deps) {
                        self::$fx_assets->inline_css_dependencies($css_deps);
                    }
                    
                    if ($js) {
                        assets_add_script([
                            'handle'    => $block_name,
                            'src'       => $js_src,
                            'inline'    => true,
                            'dependencies' => $js_deps,
                            'path'      => $js_filepath,
                        ]); 
                    } // if no js, you can still specify dependencies.
                    elseif ($js_deps) {
                        self::$fx_assets->inline_js_dependencies($js_deps);
                    } 
                    
                } else {
                    if ($css_src) {
                        assets_add_stylesheet([
                            'handle'    => $block_name,
                            'src'       => $css_src,
                            'enqueue'   => true,
                            'dependencies' => $css_deps,
                            'path'      => $css_filepath,
                        ]);
                    } // if no css, you can still specify dependencies
                    elseif ($css_deps) { 
                        foreach ($css_deps as $dep) {
                            wp_enqueue_style($dep);
                        }
                    }
                    
                    if ($js_src) {
                        // Defer dep scripts
                        // if ($js_deps) {
                            // foreach( $js_deps as $dep ) {
                                // wp_script_add_data($dep, 'defer', true);
                            // }
                        // }
                        assets_add_script([
                            'handle' => $block_name,
                            'src' => $js_src,
                            'enqueue' => true,
                            'defer' => true,  
                            'dependencies' => $js_deps,
                            'path'      => $js_filepath,
                        ]);
                        
                    } // if no js, you can still specify dependencies
                    elseif ($js_deps) {
                        foreach( $js_deps as $dep ) {
                            // dont defer jquery
                            if ( false === strpos($dep, 'jquery') )
                                wp_script_add_data($dep, 'defer', true);
                            wp_enqueue_script($dep);
                        }
                    }
                }
                
            }
            
            // If the first block contains inner blocks, we want to make sure inner block assets are added since they will be above-the-fold as well; do not increment.
            $has_inner_blocks = isset($block['innerBlocks']) && !empty( $block['innerBlocks'] );
            if ( !$first_run || !$has_inner_blocks )
                $i++;
            $first_run = false;
        } // endforeach
        
    }
    
    /** Flattens inner blocks into one array, handles reusable block
     * @param $blocks - array of blocks
     */
    public function flatten_fx_blocks($blocks) {
        
        // This will be the flattened array of all the blocks we need to process
        $new_blocks = [];
        
        foreach ($blocks as $block) {
            $block_name = $block['attrs']['name'] ?? null;
            
            if ( ! is_null($block_name) ) {
                $new_blocks[] = $block;
            } // Handle reusable blocks by adding the contained blocks to our flattened blocks for processing assets.
            else ( isset( $block['attrs']['ref'] ) ) {
                // get the reusable block
                $reusable_block_id = $block['attrs']['ref'];
                $reusable_block = get_post($reusable_block_id);
                
                // get blocks inside of reusable block
                $reusable_blocks = parse_blocks($reusable_block->post_content);
                $flattened_reusable_blocks = $this->flatten_fx_blocks($reusable_blocks);
                if (! empty($flattened_reusable_blocks ) ) {
                    $new_blocks = array_merge( $new_blocks, $flattened_reusable_blocks );
                }
            }
            
            // If inner blocks used (e.g. in column block) add them to the top-level of array by recursively grabbing innerBlocks
            if (! empty($block['innerBlocks']) ) {
                
                $inner_inner_blocks = $this->flatten_fx_blocks($block['innerBlocks']);
                if (! empty($inner_inner_blocks) )
                    $new_blocks = array_merge( $new_blocks, $inner_inner_blocks );
            }
        }

        return $new_blocks;
    }


    public static function get_post_blocks() {
        global $post;
    
        // If $post specified, use that instead of current global post
        if ( null !== $post ) {
            $result = setup_postdata($post);
            // return if error
            if ( true !== $result)
                return $result;
                
            return parse_blocks($post->post_content);
        }
        return false;
    }
    
}
 
 
function ParseBlockAssets() {
    return ParseBlockAssets::init();
}

ParseBlockAssets();