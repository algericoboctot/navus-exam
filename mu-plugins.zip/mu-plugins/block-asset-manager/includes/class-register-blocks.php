<?php


/**
 * Block Registration File
 * Contains code for registering blocks and block-assets
 * Add after plugins loaded so ACF Pro will be initialized
 */
 

class RegisterBlocks
{
    protected static $instance              = null;

    protected static $default_category      = 'fx-general-blocks';
    protected static $default_description   = 'WebFX-created block';
    protected static $default_example       = [];
    protected static $default_icon;
    protected static $default_mode          = 'edit';
    protected static $default_post_types    = [ 'page' ];

    protected $registered_blocks            = [];
    protected $custom_block_categories      = [];
    protected $path_base;
    protected $url_base;



	protected function __construct( )
    {
		self::$default_icon = fx_get_block_icon();

        $this->path_base    = get_template_directory();
        $this->url_base     = get_template_directory_uri();

        add_filter( 'block_categories', [ $this, 'set_custom_block_categories' ], 99 );
	}
	


    /**
     * Static Singleton Factory Method
     * @return self returns a single instance of our class
     */
	public static function init() 
    {
		if (!isset(self::$instance)) {
            $class_name = __CLASS__;
            self::$instance = new $class_name;
        }
        return self::$instance;
	}
	


    /** Registers acf block type, converts fx_register_block settings to
     * acf_register_block_type settings, and applies some of our default settings.
     * Required settings: 'template', 'name', 'title'
     * 'template' can either be an absolute or a relative path / filename. 
     * If the latter, it is assumed the file is located in theme_dir/block-templates/ 
     * 'css' can either be an absolute filepath or a relative path / filename. 
     * If using the latter, it is assumed the file is located in theme_dir/assets/css/blocks/
     * 'js' can either be an absolute or relative path / filename. If using the latter,
     * it is assumed the file is located in theme_dir/assets/js/blocks/
     */
	public function register_block($settings) 
    {
        
        $template = $settings['template'];
        if ( is_file($template) )
            $template_path = $template;
        else {
            $template_path = $this->path_base . '/block-templates/' . $template;
        }
        $settings['render_template'] = $template_path;
        
        $block_name = $settings['name'];
        
        $css = $settings['css'] ?? false;

        // can be either array or string
        $css_deps = $settings['css_deps'] ?? false;
        $css_deps = self::ensure_clean_array( $css_deps, ',' );
        
        $js = $settings['js'] ?? false;
        
        // can be either array or string
        $js_deps = $settings['js_deps'] ?? false;
        $js_deps = self::ensure_clean_array( $js_deps, ',' );
        
        /* Set defaults for settings */
        
        if ( !isset($settings['icon']) ) {
            $settings['icon'] = self::$default_icon;
        }
        
        if ( !isset($settings['description']) ) {
            $settings['description'] = self::$default_description;
        }
        
        if ( !isset($settings['category']) ) {
            $settings['category'] = self::$default_category;
        }
        
        if ( !isset($settings['mode']) ) {
            // Blocks with inner blocks should have mode preview for proper display.
            if ( isset( $settings['supports']['jsx'] ) && $settings['supports']['jsx'] )
                $settings['mode'] = 'preview';
            else 
                $settings['mode'] = self::$default_mode;
        }
        
        // By default, register blocks on pages only.
        if ( !isset($settings['post_types']) ) {
            $settings['post_types'] = self::$default_post_types;
        }
        
        // Enable preview by default
        if ( !isset($settings['example'] ) ) {
            $settings['example'] = self::$default_example;
        }
        
        if ( !isset( $settings['supports'] ) )
            $settings['supports'] = [];
        
        /* By enabling support for only one alignment option, we can eliminate the issue that ACF fields display improperly when re-alligned. The alignment options are unlikly to be used in our blocks anyway */
        if ( !isset(  $settings['supports']['align'] ) )
            $settings['supports']['align'] = ['full'];
        
        // Remove FX-specific settings before registering block with acf.
        unset($settings['css']);
        unset($settings['js']);
        unset($settings['template']);
        unset($settings['css_deps']);
        unset($settings['js_deps']);
        
        $registered_block = acf_register_block_type($settings);
        
        // Queue assets up in instance with block name/id as a key so we can grab them in FX_ParseBlockAssets then use FX_Assets to output them correctly.
        $this->push_block($registered_block, $css, $js, $css_deps, $js_deps);
        
        return $registered_block;
    }
    


    /** Adds the block and assets to our registrar */
    public function push_block($block, $css, $js, $css_deps = false, $js_deps = false) 
    {
        
        $settings = [
            'css_deps'   => $css_deps,
            'js_deps'    => $js_deps
        ];
        if ($css) {
            if ( is_file($css) ) {
                $src = self::get_file_src_from_path($css);
                $settings['css'] = [ 
                  'path' => $css,
                  'src' => $src,
                ];
            } else {
                $settings['css'] = [ 
                  'path' => $this->path_base . '/assets/css/blocks/' . $css,
                  'src' => $this->url_base . '/assets/css/blocks/' . $css,
                ];
            }
        } else {
            $settings['css'] = false;
        }
        if ($js) {
            if ( is_file($js) ) {
                $src = self::get_file_src_from_path($js);
                $settings['js'] = [ 
                  'path' => $js,
                  'src' => $src,
                ];
            } else {
                $settings['js'] = [
                  'path' => $this->path_base . '/assets/js/blocks/' . $js,
                  'src' => $this->url_base . '/assets/js/blocks/' . $js,
                ];
            }
        } else {
            $settings['js'] = false;
        }
        
        $this->registered_blocks[$block['name']] = $settings;
    }
    


    /** Gets a block by its name and remove it from the registrar queue */
    public function pop_block($block_name) 
    {
        $block = $this->registered_blocks[$block_name] ?? false;
        if ($block)
            unset($this->registered_blocks[$block_name]);
        
        return $block;
    }
    


    public function get_registered_blocks() 
    {
        return $this->registered_blocks;
    }
    


    /**
     * Get file url based on file path
     *
     * @param	string	$url    File URL
     * @return  mixed           String, if valid file; otherwise, false
     */
    public static function get_file_src_from_path( string $path )
    {   // Handle inconsistent filepaths
        $abspath = str_replace(
            ['/', '\\'],
            DIRECTORY_SEPARATOR,
            ABSPATH,            
        );
        $path = str_replace(
            ['/', '\\'],
            DIRECTORY_SEPARATOR,
            $path,            
        );

        // if path includes ABSPATH, remove it
        if ( false !== strpos($path, $abspath) )
                $path = substr_replace( $path, '', 0, strlen($abspath) );
        
        
        $path = str_replace(
            DIRECTORY_SEPARATOR,
            '/',
            $path,            
        );
        
        return trailingslashit(site_url()) . $path;
    }


    /**
     * Registers block category. Used for organizing blocks in Block Editor
     *
     * @param	string	$title  Category title
     * @param   string  $slug   Category slug (if blank, title is keyified)
     * @param   string  $icon   Category icon (dashicon or SVG)
     * 
     * @return  void
     */
    public function register_block_category( string $title, string $slug = '', string $icon = '' ): void
    {
        $title = trim( $title );
        if( empty( $slug ) ) {
            $slug = sanitize_title( $title );
        }

        $this->custom_block_categories[ $slug ] = [
            'icon'  => $icon,
            'title' => $title,
        ];
    }


    /**
     * Set custom block categories
     *
     * @return  array   Block categories
     */
    public function set_custom_block_categories( array $categories = [] ): array
    {
        $custom_categories = [];

        foreach( $this->custom_block_categories as $slug => $data ) {
            $custom_categories[] = [
                'icon'  => ( $data['icon'] ) ?: null,
                'slug'  => $slug,
                'title' => $data['title'],
            ];
        }

        if( !empty( $custom_categories ) ) {
            $categories = array_merge( $custom_categories, $categories );
        }

        return $categories;
    }



    /**
     * Convert argument to array with no falsey values
     *
     * @param	mixed   $arg        Argument of any type
     * @param   string  $separator  Separator for passing to explode()   
     * @return  array
     */
    public static function ensure_clean_array( $arg, string $separator = ' ' ): array
    {
        if( is_string( $arg ) ) {
            $arg = explode( $separator, $arg );
        } else {
            $arg = (array)$arg;
        }

        // cleanup array
        $arg = array_values( $arg );
        $arg = array_filter( $arg ); // remove null values
        $arg = array_map( 'trim', $arg );
        $arg = array_unique( $arg );

        return $arg;
    }
    
}
 

function RegisterBlocks() {
    return RegisterBlocks::init();
}

