<?php



defined( 'ABSPATH' ) || exit;



/**
 * FX Parse Blocks
 * 
 * Contains logic for parsing block assets and enqueuing them wherever the block is used to improve site speed.
 */
 
class Parse_Block_Assets
{
    protected static $instance      = null;

    protected static $assets     = null;
    protected static $registrar  = null;
    

    
    /**
     * Static Singleton Factory Method
     * @return self returns a single instance of our class
     */
    public static function instance() 
    {
        if( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }
	

	protected function __construct()
    {
        self::$assets    = Assets();
        self::$registrar = Register_Blocks();

        // runs with priority of 102 so script/stylesheet tags modified by FX_Assets class will be applied
		add_action( 'wp_enqueue_scripts',                   [ $this, 'enqueue_block_assets' ], 102 );
	}

    
    /** 
     * Fetch blocks in whose assets should be excluded from inlining. 
     * 
     * For example, blocks with dependencies using wp_localize_script should be excluded to prevent conflicts
     * 
     * @return  array
     */
    public static function get_blocks_excluded_from_inline(): array 
    {
        $excluded_blocks = [];

        return apply_filters( 'bam_do_not_inline_block_assets', $excluded_blocks );
    }
    

    /**
     * Loop through blocks in the_content and enqueues block assets.
     * 
     * Assets for first block will be inlined to improve paint times (can be override with 
     * fx_do_not_inline_block_assets) filter
     * 
     * @return void
     */
    public function enqueue_block_assets(): void 
    {
        $blocks = self::get_post_blocks();
        if( empty( $blocks ) ) {
            return;
        }

        // remove duplicate blocks, and extract innerblocks into single array
        $blocks = self::flatten_blocks( $blocks );
        $excluded_inline_blocks = self::get_blocks_excluded_from_inline();
        
        $block_index = 0;
        foreach( $blocks as $block ) {
            $block_name     = $block['attrs']['name'];
            $block_settings = self::$registrar->get_registered_block( $block_name );
            $block_assets   = self::get_block_assets( $block_settings );

            // if first block (and not explicitly excluded, let's inline assets)
            $inline_assets  = ( 0 === $block_index && !in_array( $block_name, $excluded_inline_blocks ) );

            if( !empty( $block_assets ) ) {
                $css            = $block_assets['css'];
                $css_src        = $css ? $css['src'] : false;
                $css_filepath   = $css ? $css['path'] : false;
                $css_deps       = $block_assets['css_deps'];
                
                $js             = $block_assets['js'];
                $js_src         = $js ? $js['src'] : false;
                $js_filepath    = $js ? $js['path'] : false;
                $js_deps        = $block_assets['js_deps'];

                // conditionally inline assets (for first block)
                if( $inline_assets ) {
                    if( !empty( $css ) ) {
                        assets_add_stylesheet( 
                            [
                                'handle'        => $block_name,
                                'src'           => $css_src,
                                'inline'        => true,
                                'dependencies'  => $css_deps,
                                'path'          => $css_filepath,
                            ]
                        );

                    // even if block doesn't have a dedicated stylesheet, inline block CSS dependencies (e.g. components)
                    } elseif( !empty( $css_deps ) ) {
                        self::$fx_assets->inline_css_dependencies( $css_deps );
                    }

                    if( !empty( $js ) ) {
                        assets_add_script(
                            [
                                'handle'        => $block_name,
                                'src'           => $js_src,
                                'inline'        => true,
                                'dependencies'  => $js_deps,
                                'path'          => $js_filepath,
                            ]
                        ); 
                    
                    // even if block doesn't have a dedicated stylesheet, inline block CSS dependencies (e.g. components)
                    } elseif( $js_deps ) {
                        self::$fx_assets->inline_js_dependencies( $js_deps );
                    } 

                } else {
                    if( !empty( $css_src ) ) {
                        assets_add_stylesheet(
                            [
                                'handle'        => $block_name,
                                'src'           => $css_src,
                                'enqueue'       => true,
                                'dependencies'  => $css_deps,
                                'path'          => $css_filepath,
                            ]
                        );
                    } elseif( !empty( $css_deps ) ) {
                        foreach( $css_deps as $css_dep ) {
                            wp_enqueue_style( $css_dep );
                        }
                    }

                    if( !empty( $js_src ) ) {
                        assets_add_script(
                            [
                                'handle'        => $block_name,
                                'src'           => $js_src,
                                'enqueue'       => true,
                                'defer'         => true,  
                                'dependencies'  => $js_deps,
                                'path'          => $js_filepath,
                            ]
                        );
                        
                    } elseif( !empty( $js_deps ) ) {
                        foreach( $js_deps as $dep ) {

                            // don't defer jQuery
                            if( false === strpos( $dep, 'jquery' ) ) {
                                wp_script_add_data( $dep, 'defer', true );
                            }

                            wp_enqueue_script( $dep );
                        }
                    }                    
                }

                // hook for theme/plugins after a specific block's assets are processed
                do_action( 'bam_after_parse_block_assets', $block );
            }

            // if first block contains inner blocks, ensure that inner block assets are also inlined
            if( empty( $block['innerBlocks'] ) ) {
                ++$block_index;
            }
        }

        // hook for theme/plugins after all block assets are processed
        do_action( 'bam_after_parse_all_block_assets', $blocks );
    }
    

    /**
     * Flatten all blocks (including inner blocks) into a single, one-level array
     *
     * @param	array   $blocks     Blocks
     * @return  array               Flattened block array
     */
    public static function flatten_blocks( array $blocks ): array 
    {
        $flattened_blocks = [];

        foreach( $blocks as $block ) {
            $block_name = $block['attrs']['name'] ?? null;

            // skip block is already added
            if( isset( $flattened_blocks[ $block_name ] ) ) {
                continue;
            }

            if( !empty( $block_name ) ) {
                $flattened_blocks[ $block_name ] = $block;

            // handle reusable blocks
            } elseif( isset( $block['attrs']['ref'] ) ) {
                $reusable_block_id = $block['attrs']['ref'];
                $reusable_block = get_post( $reusable_block_id );

                // get blocks inside block
                $reusable_blocks = parse_blocks( $reusable_block->post_content );
                $reusable_blocks = self::flatten_blocks( $reusable_blocks );

                if( !empty( $reusable_blocks ) ) {
                    $flattened_blocks = array_merge( $flattened_blocks, $reusable_blocks );
                }

            // ignore non-FX blocks
            } else {
                do_action( 'fx_bam_parse_non_fx_blocks', $block );
            }

            if( isset( $block['innerBlocks'] ) && !empty( $block['innerBlocks'] ) ) {
                $inner_blocks = self::flatten_blocks( $block['innerBlocks'] );

                if( !empty( $inner_blocks ) ) {
                    $flattened_blocks = array_merge( $flattened_blocks, $inner_blocks );
                }
            }
        }

        return array_values( $flattened_blocks );
    }


	/**
     * Get all blocks on post
     *
     * @param   int|WP_Post     $post   Optionally pass post ID or WP_Post
     * @return  array                   Array of parsed blocks     
     */
    public static function get_post_blocks( $post = null ): array
    {
        $blocks = [];

        // passed post ID?
        if( is_numeric( $post ) ) {
            $post = absint( $post );
            $post = get_post( $post );
        }

        // if not a post, try to fetch from global object
        if( !is_a( $post, 'WP_Post' ) ) {
            global $post;
        }

        // double-check that it's a post
        if( is_a( $post, 'WP_Post' ) && true === setup_postdata( $post ) ) {
            $blocks = parse_blocks( $post->post_content );
        }

        return $blocks;
    }


    /**
     * Get block stylesheet, script, and CSS/JS dependencies
     *
     * @param	array   $block_settings Block settings
     * @return  array                   Block assets
     */
    public static function get_block_assets( array $block_settings )
    {
        $assets = [
            'css'       => null,
            'js'        => null,
            'css_deps'  => $block_settings['css_deps'],
            'js_deps'   => $block_settings['js_deps'],
        ];

        if( !empty( $css = $block_settings['css'] ) ) {
            if( is_file( $css ) ) {
                $assets['css'] = [ 
                    'path'  => $css,
                    'src'   => bam_get_file_src_from_path( $css ),
                ];

            } else {
                $assets['css'] = [ 
                    'path'  => sprintf( 
                        '%s/assets/css/blocks/%s', 
                        Block_Asset_Manager()::$theme_base_path, 
                        $css 
                    ),
                    'src'   => sprintf( 
                        '%s/assets/css/blocks/%s', 
                        Block_Asset_Manager()::$theme_base_url, 
                        $css 
                    ),
                ];
            }
        }

        if( !empty( $js = $block_settings['js'] ) ) {
            if( is_file( $js ) ) {
                $assets['js'] = [ 
                    'path'  => $js,
                    'src'   => bam_get_file_src_from_path( $js ),
                ];

            } else {
                $assets['js'] = [ 
                    'path'  => sprintf( 
                        '%s/assets/js/blocks/%s', 
                        Block_Asset_Manager()::$theme_base_path, 
                        $js 
                    ),
                    'src'   => sprintf( 
                        '%s/assets/js/blocks/%s', 
                        Block_Asset_Manager()::$theme_base_url, 
                        $js 
                    ),
                ];
            }
        }

        return $assets;
    }
    
}
 
 
function Parse_Block_Assets() {
    return Parse_Block_Assets::instance();
}

Parse_Block_Assets();