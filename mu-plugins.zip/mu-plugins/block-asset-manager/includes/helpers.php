<?php

/** Returns the contents of theme_dir/assets/icons/block-icon.svg */
function get_block_icon() {
    $filepath = get_stylesheet_directory() . '/assets/icons/block-icon.svg';

    if( is_file( $filepath ) ) {
        return file_get_contents( $filepath );
    }

    return '';
}


/* FX Function to quickly register an ACF block.
 * Documentation: https://bit.ly/3ftQrYp
 * Requires ACF Plugin to be enabled and active.
 * @param Array $settings - array of settings to use when registering the block
 *      you can use any setting available in acf_register_block_type
 */
function register_block( $settings ) {
    if (function_exists('acf_register_block_type') ) {
        $block_register = RegisterBlocks();
        return $block_register->register_block( $settings );
    } else {
        return false;
    }
}


/**
 * Add script
 * 
 * @see     FX_Assets()->add_script
 *
 * @param	array   $args   Stylesheet args
 * @return  mixed   True, if successful; otherwise WP_Error
 */
function assets_add_script( array $args ) {
    return Assets()->add_script( $args );
}


/**
 * Add stylesheet
 * 
 * @see     FX_Assets()->add_stylesheet
 *
 * @param	array   $args   Script args
 * @return  mixed   True, if successful; otherwise WP_Error
 */
function assets_add_stylesheet( array $args ) {
    return Assets()->add_stylesheet( $args );
}


/**
 * Registers custom plugin stylesheet dependencies for later usage
 *
 * @param	string	$plugin_handle  Plugin asset handle
 * @param   string  $handle_to_add  Asset handle to add to plugin's dependencies
 * 
 * @return  void
 */
function assets_add_plugin_style( string $plugin_handle, string $handle_to_add ) {
    return Assets()->register_custom_plugin_style_dependency( $plugin_handle, $handle_to_add );
}


/**
 * Registers custom plugin script dependencies for later usage
 *
 * @param	string	$plugin_handle  Plugin asset handle
 * @param   string  $handle_to_add  Asset handle to add to plugin's dependencies
 * 
 * @return  void
 */
function assets_add_plugin_script( string $plugin_handle, string $handle_to_add ) {
    return Assets()->register_custom_plugin_script_dependency( $plugin_handle, $handle_to_add );
}


/**
 * Returns minified CSS
 *
 * @param	string	$content    CSS
 * @return  string              Minified CSS
 */
function asset_minify_css( string $content ) {
    return Asset_Minifier()->minify_content( $content, 'css' );
}


/**
 * Returns minified JS
 *
 * @param	string	$content    JS
 * @return  string              Minified JS
 */
function asset_minify_js( string $content ) {
    return Asset_Minifier()->minify_content( $content, 'js' );
}


/**
 * Takes a CSS file and returns minified CSS
 *
 * @param	string	$content    CSS
 * @return  string              Minified CSS
 */
function asset_minify_stylesheet( string $file_path ) {
    return Asset_Minifier()->minify_file( $file_path, 'css' );
}


/**
 * Takes a JS file and returns minified JS
 *
 * @param	string	$content    JS
 * @return  string              Minified JS
 */
function asset_minify_script( string $file_path ) {
    return Asset_Minifier()->minify_file( $file_path, 'js' );
}


/**
 * Wrapper for registering a block category
 *
 * @param	string	$title      Category title
 * @param   string  $slug       Category slug
 * @param   string  $icon       Category icon (dashicon or SVG)
 * 
 * @return  void
 */
function add_block_category( string $title, string $slug = '', string $icon = '' ): void {
    RegisterBlocks()->register_block_category( $title, $slug, $icon );
}