<?php


/**
 * Plugin Name: Block and Asset Manager
 * Version:     0.1.2
 * Description: Allows for easy registration of blocks and assets
 * Author:      N/A
 * Author URI:  N/A
 * Plugin URI:  N/A

 */


require_once( __DIR__ . '/block-asset-manager/index.php' );