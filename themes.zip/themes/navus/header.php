<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <!-- Poppins Font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@0,100..900;1,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <!-- Raleway Font -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@0,100..900;1,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100..900;1,100..900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <!-- font-family: 'Montserrat', sans-serif; -->

    <style type="text/tailwindcss">
        @tailwind base;
        @tailwind components;
        @tailwind utilities;

        @layer utilities {
            .container {
                max-width: 1170px;
            }
        }
    </style>
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

    <?php wp_body_open(); ?>
    <main>
        <?php
            // get fields data set in Theme Settings
            $logo_id        =   get_client_logo_image_id(); 
            $cta            =   get_field('cta_link','option');

            $home_url       =   get_home_url();
        ?>
    <header>
        <div class="container mx-auto px-[15px] pt-4 xl:pt-12">
            <div class="flex flex-wrap">
                <div class="logo w-1/2 lg:w-auto order-1 lg:mr-auto">
                    <a class="w-[160px] h-[42px] xl:w-[183px] xl:h-[54px] relative block" href="<?php echo esc_url( $home_url ); ?>">
                        <?php echo theme_get_image_tag( $logo_id, 'w-full h-full object-contain' ); ?> 
                    </a>
                </div>
                <div class="order-3 lg:order-2 w-full lg:w-auto mt-4 lg:mt-0 lg:flex lg:items-center">
                    <?php
                        // Output the footer navigation
                        wp_nav_menu(
                            [
                                'container'         => 'nav',
                                'container_class'   => 'nav-menu',
                                'theme_location'    => 'main_menu',
                                'menu_class'        => 'header-nav flex flex-col sm:flex-row flex-wrap items-center sm:justify-center'
                            ]
                        );
                    ?>
                </div>
                <div class="w-1/2 lg:w-auto order-2 lg:order-3 xl:mx-[40px]">
                    <a class="ml-auto uppercase w-[158px] h-[48px] xl:w-[178px] xl:h-[53px] leading-[40px] xl:leading-[47px] text-center block border-[3px] border-black hover:border-[#ECDD4D] hover:text-[#ECDD4D] transition delay-200 cta" href="<?php echo $cta['url'];?>" target="_new">
                        <?php echo $cta['label'];?>
                    </a>
                </div>
            </div>
        </div>
    </header>
