<?php
    if ( isset($block['data']['content_image']) ) {
        $content_image = $block['data']['content_image'];
        echo '<img src="' . $content_image . '">';
    } else {
?>

<div class="container-fluid mt-7 xl:mt-12">
    <?php
        $title = get_field('content_image_title');
        $description = get_field('content_image_desc');
        $banner = get_field('content_image_banner');
    ?>
    <div class="flex flex-wrap flex-row lg:mb-[100px]">
        <div class="w-full lg:w-1/2 lg:mb-8 order-2 lg:order-1 pt-8 xl:pt-0">
            <div class="flex h-full">
                <div class="lg:ml-auto lg:w-[586px] flex flex-wrap flex-col justify-center px-4">
                    <h1 class="highlight-last-word text-3xl md:text-4xl xl:text-6xl mb-4 xl:mb-12">
                        <?php echo $title;?>
                    </h1>
                    <div class="text-xs sm:text-sm md:text-base lg:text-xl mb-4">
                        <?php echo $description;?>
                    </div>
                </div>
            </div>
        </div>
        <div class="w-full lg:w-1/2 lg:pl-12 order-1 lg:order-2 relative">
            <?php if ( !empty($banner) ) { ?>
                <?php echo theme_get_image_tag( $banner, 'z-0 relative w-full h-full object-cover' ); ?> 
                <div class="hidden lg:block w-[230px] md:w-[280px] lg:w-[305px] h-[122px] md:h-[152px] lg:h-[168px] md:absolute md:z-10 bottom-[-61px] md:bottom-[-76px] lg:bottom-[-100px] md:right-0">
                    <svg class="w-full h-full" viewBox="0 0 305 168" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect y="42.588" width="38.844" height="38.844" fill="#ECDD4D"/>
                        <rect x="79.092" y="85.1759" width="38.844" height="38.844" fill="black" fill-opacity="0.9"/>
                        <rect x="126.36" width="110.448" height="38.844" fill="#ECDD4D"/>
                        <rect x="240.552" y="42.588" width="110.448" height="38.844" fill="black" fill-opacity="0.9"/>
                        <rect x="127.764" y="128.7" width="110.448" height="38.844" fill="#ECDD4D"/>
                    </svg>

                </div>
                <?php } ?>
        </div>
    </div>
</div>

<?php 
    } // end of isset
?>