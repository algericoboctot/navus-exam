<?php
    if ( isset($block['data']['service-guide']) ) {
        $service_guide = $block['data']['service-guide'];
        echo '<img src="' . $service_guide . '">';
    } else {
?>
<div class="flex flex-wrap relative bg-[#ecdd4d] mt-10 lg:mt-[120px] lg:pb-[80px]">
    <div class="hidden lg:block lg:absolute lg:w-[263px] lg:h-[168px] lg:ml-auto lg:right-0 lg:top-[-84px]">
        <svg class="w-full h-full" viewBox="0 0 263 168" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="271.908" y="82.368" width="38.844" height="38.844" transform="rotate(180 271.908 82.368)" fill="black" fill-opacity="0.9"/>
            <rect x="224.64" y="167.544" width="110.448" height="38.844" transform="rotate(180 224.64 167.544)" fill="black" fill-opacity="0.9"/>
            <rect x="110.448" y="124.956" width="110.448" height="38.844" transform="rotate(180 110.448 124.956)" fill="black" fill-opacity="0.9"/>
            <rect x="223.236" y="38.844" width="110.448" height="38.844" transform="rotate(180 223.236 38.844)" fill="#ECDD4D"/>
        </svg>
    </div>
    <div class="container relative z-10 mx-auto py-4 md:py-6 px-4 xl:py-12 lg:mt-[80px]">
            <?php
                $heading = get_field('title');
            ?>

            <h2 class="highlight-last-word white font-bold text-3xl md:text-4xl xl:text-6xl mb-4 sm:mb-6 md:mb-8 lg:mb-10 xl:mb-20">
                <?php echo $heading;?>
            </h2>
            

            
            <?php if ( have_rows('service_guide') ) :?>
                <div class="relative py-5 sm:py-6 md:py-8 lg:py-9 xl:py-10">
                    <div class="service-guide-steps mb-6"></div>
                    <div class="service-guide-listing">
                        <?php while( have_rows( 'service_guide' ) ): the_row();?>
                            <div>
                                <div class="text-xs sm:text-sm md:text-base lg:text-xl mb-4 md:mb-5 lg:mb-8 xl:mb-12">
                                    <?php the_sub_field( 'content' ); ?>
                                </div>
                                <div class="flex flex-wrap flex-row items-center">
                                    <div>
                                        <?php
                                            $title = get_sub_field('title');
                                            $description = get_sub_field('description');
                                        ?>
                                        <?php if ($title) : ?>
                                            <h3 class="lg:text-[35px] mb-4 lg:mb-6 xl:mb-8"><?php echo $title; ?></h3>
                                        <?php endif; ?>
                                        <?php if ($description) : ?>
                                                <div class="text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl">
                                                    <?php echo $description ?>
                                                </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
                
            <?php endif; ?>
    </div>

    

</div>
<?php } ?>