<?php
    if ( isset($block['data']['testimonials']) ) {
        $testimonials = $block['data']['testimonials'];
        echo '<img src="' . $testimonials . '">';
    } else {
?>
<div class="container mx-auto py-4 px-4 xl:py-12">
        <?php
            $heading = get_field('title');
        ?>

        <h2 class="highlight-last-word text-3xl md:text-4xl xl:text-6xl mb-4 sm:mb-6 md:mb-8 lg:mb-10 xl:mb-20">
            <?php echo $heading;?>
        </h2>
        

        
        <?php if ( have_rows('testimonial_listing') ) :?>
            <div class="relative border-[1px] border-black p-5 sm:p-6 md:p-8 lg:p-9 xl:p-12">
                <div class="z-10 top-[-11px] lg:top-[-22px] left-5 sm:left-6 md:left-7 lg:left-12 absolute w-[27px] h-[24px] lg:w-[47px] lg:h-[44px]">
                    <svg class="w-full h-full" viewBox="0 0 47 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M17.4778 24.8417V44H0V28.875C0 20.6861 0.96596 14.7583 2.89788 11.0917C5.43353 6.20278 9.4483 2.50556 14.9422 0L18.9268 6.41667C15.6063 7.82222 13.1612 9.93056 11.5915 12.7417C10.0218 15.4917 9.14644 19.525 8.96532 24.8417H17.4778ZM45.5511 24.8417V44H28.0732V28.875C28.0732 20.6861 29.0392 14.7583 30.9711 11.0917C33.5067 6.20278 37.5215 2.50556 43.0154 0L47 6.41667C43.6795 7.82222 41.2344 9.93056 39.6647 12.7417C38.0951 15.4917 37.2197 19.525 37.0385 24.8417H45.5511Z" fill="black"/>
                    </svg>
                </div>
                <div class="slick-arrows flex flex-row flex-wrap w-full h-[35.5px] lg:h-[55.5px] absolute z-0 top-0 left-0"></div>
                <div class="testimonial-listing z-10">
                    <?php while( have_rows( 'testimonial_listing' ) ): the_row();?>
                        <div>
                            <div class="text-xs sm:text-sm md:text-base lg:text-xl mb-4 md:mb-5 lg:mb-8 xl:mb-12">
                                <?php the_sub_field( 'content' ); ?>
                            </div>
                            <div class="flex flex-wrap flex-row items-center">
                                <div class="w-[54px] lg:w-[94px] h-[54px] lg:h-[94px] rounded-full overflow-hidden mr-[10px] sm:mr-[16px] md:mr-[20px] xl:mr-[30px]">
                                    <?php
                                        $image_id = get_sub_field('image');
                                    ?>

                                    <?php echo theme_get_image_tag( $image_id, 'z-0 relative w-full h-full object-cover' ); ?> 
                                </div>
                                <div>
                                    <?php
                                        $name = get_sub_field('name');
                                        $position = get_sub_field('position');
                                        $company = get_sub_field('company');
                                    ?>
                                    <?php if ($name) : ?>
                                        <h4 class="text-black text-[17px] md:text-[19px] lg:text-[21px] xl:text-[25px]"><?php echo $name ?></h4>
                                    <?php endif; ?>
                                    <div class="text-black text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl">
                                        <?php if ($position) : ?>
                                            <div><?php echo $position ?></div>
                                        <?php endif; ?>
                                        <?php if ($company) : ?>
                                            <div><?php echo $company ?></div>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <div class="slick-pagination mt-4 sm:mt-5 md:mt-7 lg:mt-8"></div>
        <?php endif; ?>
</div>
<?php } ?>