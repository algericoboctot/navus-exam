<?php

/**
 * Register and enqueue theme styles
 *
 * @return void
 */

add_action( 'wp_enqueue_scripts', 'theme_styles' );

function theme_styles() {
    $theme_dir = get_stylesheet_directory();
    $theme_url = get_stylesheet_directory_uri();

    /* Inline critical/above-the-fold stylesheets */
    
    assets_add_stylesheet(
        [
            'handle'    => 'site-global',
            'src'       => $theme_url . '/assets/css/global.css',
            'inline'    => true
        ]
    );

    assets_add_stylesheet(
        [
            'handle'    => 'header',
            'src'       => $theme_url . '/assets/css/header.css',
            'inline'    => true
        ]
    );

    assets_add_stylesheet(
        [
            'handle'    => 'slick_plugin_css',
            'src'       => $theme_url . '/assets/css/plugins/slick.css',
        ]
    );

    assets_add_stylesheet(
        [
            'handle'    => 'site-footer',
            'src'       => $theme_url . '/assets/css/footer.css',
            'enqueue'   => !is_admin()
        ]
    );
}

/**
 * Register and enqueue theme scripts
 *
 * @return void
 */
add_action( 'wp_enqueue_scripts', 'theme_scripts' );

function theme_scripts() {
    $theme_dir = get_stylesheet_directory();
    $theme_url = get_stylesheet_directory_uri();

    // Scripts that must be included on every page.
    assets_add_script(
        [
            'handle'        => 'site-global',
            'src'           => $theme_url . '/assets/js/global.js',
            'dependencies'  => [ 'jquery' ],
            'enqueue'       => !is_admin(),
            'defer'         => true,
            'preload'       => true,
        ]
    );

    // Custom styling for slick library
    assets_add_script(
        [
            'handle'        => 'slick_plugin_js',
            'src'           => $theme_url . '/assets/js/plugins/slick.js',
            'dependencies'  => [ 'jquery' ],
            'enqueue'       => !is_admin(),
            'async'         => true
        ]
    );
    
}

/** Remove jquery migrate as a jquery dependency on the front end to improve load times. */
add_action( 'wp_default_scripts', 'fx_dequeue_jquery_migrate' );
function fx_dequeue_jquery_migrate( $scripts ) {
    if ( ! is_admin() && ! empty( $scripts->registered['jquery'] ) ) {
        $scripts->registered['jquery']->deps = array_diff(
            $scripts->registered['jquery']->deps,
            [ 'jquery-migrate' ]
        );
    }
}