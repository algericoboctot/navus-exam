<?php

/**
 * Register blocks
 * 
 * register_block() is, at its core, a wrapper function for acf_register_block_type with additional parameters for 
 * our supporting functionality
 * 
 * Below is a reference for the parameters you can pass to register_block(). You can also pass any setting from 
 * register_block_type() to register_acf_block().
 * 
 * Required arguments: "name", "title", and "template"
 * 
 */

$theme_url = get_stylesheet_directory_uri();

// @todo — remove $reference_settings before launch
$reference_settings = array(
    'name'          => '', // (required) (string) unique name to identify block (no spaces)
    'title'         => '', // (required) (string) display title for block
    'template'      => '', // (required) (string) relative path of the template we'll use to load this block (in block-templates/), Ex: innerpage/template.php
    'css'           => '', // (string) block-specific stylesheet path. Assumed to be in /themes/fx/assets/css, so use relative path (e.g. "homepage/homepage-block.css")
    'css_deps'      => [], // (array) CSS dependency handles. These stylesheets will be loaded before this block's specific stylesheet. Dependencies must already be registered.
    'js'            => '', // (string) block-specific script path. Assumed to be in /themes/fx/assets/js, so use relative path (e.g. "homepage/homepage-block.js")
    'js_deps'       => [], // (array) JS dependency handles. These scripts will be loaded before this block's specific script. Dependencies must already be registered.
    'description'   => '', // (string) short description of block. Optional, but blocks should have useful descriptions to indicate purpose of block.
    'category'      => '', // (string) declares which category in the block editor block belongs to. Options: "text", "media", "design", "widgets", and "embed". You can define your own categories.
    'icon'          => '', // (array|string) can be a dashicon or SVG image used to identify the block
    'keywords'      => '', // (array) terms to help find block in block editor
    'post_types'    => [], // (array) if declared, will restrict block to being available for only specified post types. Default is "page".
    'mode'          => '', // (string) display mode for block when you add block in editor. Options: "auto", "preview", "edit". If no mode is selected, it will automatically be set to "edit", unless your block is an "outer block" in which case the default mode should be "preview". Due to these defaults, It is unlikely you will need to use this setting very often. Note: for large acf groups, such as repeaters, it is recommended to stick with the default "edit" mode.
    'supports'      => '', // (associative array) features to support. See https://developer.wordpress.org/block-editor/developers/block-api/block-supports/
);


/**
 * General blocks
 * 
 * These blocks are intended to be used anywhere, including the homepage and innerpage.
 * 
 * Block template path: /themes/block-templates/general
 * Stylesheet path:     /themes/assets/css/general
 * Script path:         /themes/assets/js/general
 * 
 */


/**
 * Create a "FX General Blocks" category in the block editor. Use "fx-general-blocks" as your "category" value in 
 * fx_register_block()
 * 
 */
add_block_category( 'General Blocks', 'general-blocks' );


/**
 * Content Left image Right Block
 * 
 */
register_block(
    [
        'name'          => 'content-image',
        'title'         => 'Content Image Block',
        'template'      => 'content-image.php',
        'description'   => 'A Block with Content on the left, and an image on the right',
        'css'           => 'content-image.css',
        'example'  => array(
            'attributes' => array(
                'mode' => 'preview',
                'data' => array(
                    'content_image' => $theme_url.'/assets/images/block-preview-images/content-image-block.jpg',
                    'is_preview'    => true
                )
            )
        )
    ]
);

/**
 * Testimonials Block
 * 
 */
register_block(
    [
        'name'          => 'testimonials',
        'title'         => 'Testimonials',
        'template'      => 'testimonials.php',
        'description'   => 'A testimonial block',
        'css'           => 'testimonials.css',
        'css_deps'      => 'slick_plugin_css',
        'js'            => 'testimonials.js',
        'js_deps'       => ['slick_plugin_js'],
        'example'  => array(
            'attributes' => array(
                'mode' => 'preview',
                'data' => array(
                    'content_image' => $theme_url.'/assets/images/block-preview-images/testimonials-block.jpg',
                    'is_preview'    => true
                )
            )
        )
    ]
);

/**
 * Service Guide Block
 * 
 */

register_block(
    [
        'name'          => 'service-guide',
        'title'         => 'Service Guide',
        'template'      => 'service-guide.php',
        'description'   => 'Service Guide block',
        'css'           => 'service-guide.css',
        'css_deps'      => 'slick_plugin_css',
        'js'            => 'service-guide.js',
        'js_deps'       => ['slick_plugin_js'],
        'example'  => array(
            'attributes' => array(
                'mode' => 'preview',
                'data' => array(
                    'content_image' => $theme_url.'/assets/images/block-preview-images/service-guide-block.jpg',
                    'is_preview'    => true
                )
            )
        )
    ]
);