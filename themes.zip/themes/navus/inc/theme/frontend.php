<?php

/**
 * Set Up theme support and functionality
 *
 * @return void
 */
add_action( 'after_setup_theme', 'theme_support_setup' );
function theme_support_setup() {
    add_editor_style();
    add_theme_support( 'title-tag' );

    // Theme Images
    add_theme_support( 'post-thumbnails' );

    // HTML5 Support
    add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );
}

/**
 * Register menu functionality, initilize plugin functionality
 *
 * @return void
 */
add_action( 'init', 'register_menu_init' );
function register_menu_init() {
    // Register Menu
    register_nav_menus(
        array(
            'footer_menu'  => 'Navigation items for footer navigation.',
            'main_menu' => 'Navigation items for the main menu.'
        )
    );
}