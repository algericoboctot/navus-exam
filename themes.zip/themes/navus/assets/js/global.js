var GLOBALJQuery = ( function( GLOBALJQuery, $ ) {
    /**
	 * Doc Ready
	 * 
	 * Use a separate $(function() {}) block for each function call
	 */
	$( () => {
		GLOBALJQuery.General.init(); // For super general or super short scripts
	})
    
    /**
	 * General functionality — ideal for one-liners or super-duper short code blocks
	 */
    GLOBALJQuery.General = {
        
        init() {
            this.bind();
        },

        bind() {

            $('.highlight-last-word').each(function() {
                const text = $(this).text().trim();
                const lastSpaceIndex = text.lastIndexOf(" ");
                
                if (lastSpaceIndex !== -1) {
                    const firstPart = text.substring(0, lastSpaceIndex);
                    const lastWord = text.substring(lastSpaceIndex + 1);
                    
                    $(this).html(`${firstPart} <span class="yellow"><span class="text-bg"></span><span class="text">${lastWord}</span></span>`);
                }
            });
        }
    };

	

	return GLOBALJQuery;

} ( GLOBALJQuery || {}, jQuery ) );