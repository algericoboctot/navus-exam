var SERVICE_GUIDE = ( function( SERVICE_GUIDE, $ ) {


	$( () => {
		SERVICE_GUIDE.ServiceGuideSlider.init()
	})


	SERVICE_GUIDE.ServiceGuideSlider = {
		$slider: null,

		init() {

			$('.service-guide-listing').slick({
				infinite: true,
				speed: 300,
				dots: true,
				arrows: false,
                fade: true,
				slidesToShow: 1,
				appendDots: $('.service-guide-steps')
			});
		},

	}

	

	return SERVICE_GUIDE

} ( SERVICE_GUIDE || {}, jQuery ) )