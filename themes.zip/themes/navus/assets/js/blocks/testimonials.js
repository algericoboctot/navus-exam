var TESTIMONIALS = ( function( TESTIMONIALS, $ ) {


	$( () => {
		TESTIMONIALS.TestimonialSlider.init()
	})


	TESTIMONIALS.TestimonialSlider = {
		$slider: null,

		init() {

			$('.testimonial-listing').slick({
				infinite: true,
				speed: 300,
				dots: true,
				arrows: true,
				slidesToShow: 1,
				appendDots: $('.slick-pagination'),
				appendArrows: $('.slick-arrows'),
				prevArrow: '<button type="button" class="slick-prev"><span></span></button>',
				nextArrow: '<button type="button" class="slick-next"><span></span></button>',
				responsive: [
					{
					  breakpoint: 1024,
					  settings: {
						dots: true,
						arrows: false,
					  }
					}
				
				  ]
			});
		},

	}

	

	return TESTIMONIALS

} ( TESTIMONIALS || {}, jQuery ) )